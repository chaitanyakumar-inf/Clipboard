import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Database from "better-sqlite3";
import cors from "cors";
import fs from "fs";
import multer from "multer";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("itweet.db");

// Ensure uploads directory exists
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only images are allowed'));
    }
  }
});

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT UNIQUE,
    handle TEXT UNIQUE,
    name TEXT,
    avatar_url TEXT,
    bio TEXT,
    banner_url TEXT,
    is_private INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Seed some users if none exist
  INSERT OR IGNORE INTO users (phone, handle, name, avatar_url, bio) 
  SELECT '0000000001', 'itweet_official', 'iTweet Official', 'https://picsum.photos/seed/itweet/200', 'The official account for iTweet updates!'
  WHERE (SELECT COUNT(*) FROM users) = 0;
  
  INSERT OR IGNORE INTO users (phone, handle, name, avatar_url, bio) 
  SELECT '0000000002', 'tech_guru', 'Tech Guru', 'https://picsum.photos/seed/tech/200', 'Sharing the latest in tech and AI.'
  WHERE (SELECT COUNT(*) FROM users) <= 1;

  INSERT OR IGNORE INTO users (phone, handle, name, avatar_url, bio) 
  SELECT '0000000003', 'design_daily', 'Design Daily', 'https://picsum.photos/seed/design/200', 'Your daily dose of design inspiration.'
  WHERE (SELECT COUNT(*) FROM users) <= 2;

  INSERT OR IGNORE INTO users (phone, handle, name, avatar_url, bio) 
  SELECT '0000000004', 'nature_vibes', 'Nature Vibes', 'https://picsum.photos/seed/nature/200', 'Capturing the beauty of the world.'
  WHERE (SELECT COUNT(*) FROM users) <= 3;

  CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    content TEXT,
    image_url TEXT,
    is_gen_ai INTEGER DEFAULT 0,
    likes_count INTEGER DEFAULT 0,
    dislikes_count INTEGER DEFAULT 0,
    comments_count INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS post_interactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    post_id INTEGER,
    type TEXT, -- 'like', 'dislike', 'save'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, post_id, type),
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(post_id) REFERENCES posts(id)
  );

  CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    post_id INTEGER,
    content TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(post_id) REFERENCES posts(id)
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER,
    receiver_id INTEGER,
    content TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(sender_id) REFERENCES users(id),
    FOREIGN KEY(receiver_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS follows (
    follower_id INTEGER,
    following_id INTEGER,
    status INTEGER DEFAULT 1, -- 0: pending, 1: accepted
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(follower_id, following_id),
    FOREIGN KEY(follower_id) REFERENCES users(id),
    FOREIGN KEY(following_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    actor_id INTEGER,
    type TEXT,
    post_id INTEGER,
    content TEXT,
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(actor_id) REFERENCES users(id),
    FOREIGN KEY(post_id) REFERENCES posts(id)
  );
`);

// Ensure columns exist for existing databases
try { db.exec("ALTER TABLE users ADD COLUMN bio TEXT"); } catch(e) {}
try { db.exec("ALTER TABLE users ADD COLUMN banner_url TEXT"); } catch(e) {}
try { db.exec("ALTER TABLE users ADD COLUMN is_private INTEGER DEFAULT 0"); } catch(e) {}
try { db.exec("ALTER TABLE follows ADD COLUMN status INTEGER DEFAULT 1"); } catch(e) {}

const createNotification = (userId: number, actorId: number, type: string, postId?: number, content?: string) => {
  if (userId === actorId) return; // Don't notify self
  db.prepare("INSERT INTO notifications (user_id, actor_id, type, post_id, content) VALUES (?, ?, ?, ?, ?)")
    .run(userId, actorId, type, postId || null, content || null);
};

// Seed some data if empty
const userCount = db.prepare("SELECT COUNT(*) as count FROM users").get() as { count: number };
if (userCount.count === 0) {
  const insertUser = db.prepare("INSERT INTO users (phone, handle, name, avatar_url) VALUES (?, ?, ?, ?)");
  insertUser.run("+11234567890", "itweet", "iTweet Official", "https://api.dicebear.com/7.x/avataaars/svg?seed=itweet");
  insertUser.run("+19876543210", "sarahj_design", "Sarah Jenkins", "https://lh3.googleusercontent.com/aida-public/AB6AXuAMP-5pmrHyRlKwINDfQ2WpevEwypdvYnaylaFS1ZLKLF3wwhDxSPsyaJfnOhIyJ7nRI5cMV7YIaPWG2A848HxwR17LxDyZJmDX2rDUwAd09stkE2-IMBR4YGWpWTU9H3vyZhI65dlkPnbJKX0fy9d0S_M8aqGm-8mXScnUUcvvB6HSOAHvCBf6P5z3wqudusMm__VGn3CO8xojdxetMGkCeaLTcw9pQ0itKWRl-yDGKR4wstTbmUpwvGNWONAL_oW2cGM0FZC0qdM");
  
  const insertPost = db.prepare("INSERT INTO posts (user_id, content, image_url, is_gen_ai) VALUES (?, ?, ?, ?)");
  insertPost.run(1, "Welcome to iTweet! The future of high-fidelity social media is here.", null, 0);
  insertPost.run(2, "The convergence of silicon and biology isn't just a prediction—it's an awakening.", "https://lh3.googleusercontent.com/aida-public/AB6AXuDNS6xfOQRS_NhNfstVuVw_bug4oYo1bs0yob_zi3iBT1wOFpY-cbWTDmf8glNiOwf2b-SIFjdMAnG6IcGAW4OVWspLtud1aIj5vkyBHpQDxQGe-GzSHnPHrsJ3r5WKlVfXThR0UOJ7GorrIZTDpO4ZkjECP92tWMPIcYNZqo9Ll7n1_JK4dIDZiqm0RUUpg2jBkb1reJSuLTHWDsIj2cgZApxuBlnmzXAV8tMh0uuNZPZEZIyAR12r800GXr5vhcx-7aR8kue-opk", 1);
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // Mock OTP storage
  const otps = new Map<string, string>();

  // Auth Endpoints
  app.post("/api/auth/request-otp", (req, res) => {
    const { phone } = req.body;
    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    otps.set(phone, otp);
    res.json({ success: true, otp }); // In real app, don't return OTP here
  });

  app.post("/api/auth/verify-otp", (req, res) => {
    const { phone, otp } = req.body;
    if (otps.get(phone) === otp) {
      otps.delete(phone);
      const user = db.prepare("SELECT * FROM users WHERE phone = ?").get(phone) as any;
      if (user) {
        res.json({ success: true, newUser: !user.handle, user });
      } else {
        const result = db.prepare("INSERT INTO users (phone) VALUES (?)").run(phone);
        const newUser = db.prepare("SELECT * FROM users WHERE id = ?").get(result.lastInsertRowid);
        res.json({ success: true, newUser: true, user: newUser });
      }
    } else {
      res.status(400).json({ success: false, message: "Invalid OTP" });
    }
  });

  app.post("/api/auth/register", (req, res) => {
    const { userId, handle, name } = req.body;
    try {
      db.prepare("UPDATE users SET handle = ?, name = ?, avatar_url = ? WHERE id = ?")
        .run(handle, name || handle, `https://api.dicebear.com/7.x/avataaars/svg?seed=${handle}`, userId);
      const user = db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
      res.json({ success: true, user });
    } catch (e: any) {
      res.status(400).json({ success: false, message: e.message });
    }
  });

  // Feed Endpoints
  app.get("/api/feed", (req, res) => {
    const { userId } = req.query;
    const currentUserId = Number(userId) || 0;
    const posts = db.prepare(`
      SELECT posts.*, users.handle, users.name, users.avatar_url,
      (SELECT COUNT(*) FROM post_interactions WHERE post_id = posts.id AND type = 'like') as likes_count,
      (SELECT COUNT(*) FROM post_interactions WHERE post_id = posts.id AND type = 'dislike') as dislikes_count,
      (SELECT 1 FROM post_interactions WHERE post_id = posts.id AND user_id = ? AND type = 'save') as is_saved,
      (SELECT type FROM post_interactions WHERE post_id = posts.id AND user_id = ? AND type IN ('like', 'dislike')) as user_interaction
      FROM posts 
      JOIN users ON posts.user_id = users.id 
      WHERE users.is_private = 0 
         OR users.id = ? 
         OR EXISTS (SELECT 1 FROM follows WHERE follower_id = ? AND following_id = users.id AND status = 1)
      ORDER BY posts.created_at DESC
    `).all(currentUserId, currentUserId, currentUserId, currentUserId);
    res.json(posts);
  });

  app.get("/api/search", (req, res) => {
    const { q, userId } = req.query;
    const query = `%${q}%`;
    
    const users = db.prepare(`
      SELECT u.*, 
      (SELECT status FROM follows WHERE follower_id = ? AND following_id = u.id) as follow_status
      FROM users u 
      WHERE (handle LIKE ? OR name LIKE ?) AND u.id != ?
      LIMIT 10
    `).all(userId || 0, query, query, userId || 0);

    const posts = db.prepare(`
      SELECT posts.*, users.handle, users.name, users.avatar_url,
      (SELECT COUNT(*) FROM post_interactions WHERE post_id = posts.id AND type = 'like') as likes_count,
      (SELECT COUNT(*) FROM post_interactions WHERE post_id = posts.id AND type = 'dislike') as dislikes_count,
      (SELECT COUNT(*) FROM comments WHERE post_id = posts.id) as comments_count,
      (SELECT type FROM post_interactions WHERE post_id = posts.id AND user_id = ? AND type IN ('like', 'dislike')) as user_interaction,
      (SELECT 1 FROM post_interactions WHERE post_id = posts.id AND user_id = ? AND type = 'save') as is_saved
      FROM posts 
      JOIN users ON posts.user_id = users.id 
      WHERE content LIKE ? 
      ORDER BY posts.created_at DESC LIMIT 20
    `).all(userId || 0, userId || 0, query);
    
    res.json({ users, posts });
  });

  app.post("/api/posts/:id/interact", (req, res) => {
    const { id } = req.params;
    const { userId, type } = req.body; // type: 'like', 'dislike', 'save'
    
    try {
      const existing = db.prepare("SELECT * FROM post_interactions WHERE user_id = ? AND post_id = ? AND type = ?").get(userId, id, type);
      
      if (existing) {
        db.prepare("DELETE FROM post_interactions WHERE user_id = ? AND post_id = ? AND type = ?").run(userId, id, type);
        res.json({ success: true, action: 'removed' });
      } else {
        if (type === 'like' || type === 'dislike') {
          // Remove opposite interaction if it exists
          const opposite = type === 'like' ? 'dislike' : 'like';
          db.prepare("DELETE FROM post_interactions WHERE user_id = ? AND post_id = ? AND type = ?").run(userId, id, opposite);
        }
        db.prepare("INSERT INTO post_interactions (user_id, post_id, type) VALUES (?, ?, ?)").run(userId, id, type);
        
        if (type === 'like') {
          const post = db.prepare("SELECT user_id FROM posts WHERE id = ?").get(id) as any;
          if (post) createNotification(post.user_id, userId, 'like', Number(id));
        }
        
        res.json({ success: true, action: 'added' });
      }
    } catch (e: any) {
      res.status(400).json({ success: false, message: e.message });
    }
  });

  app.delete("/api/posts/:id", (req, res) => {
    const { id } = req.params;
    const userId = Number(req.query.userId);
    
    const post = db.prepare("SELECT * FROM posts WHERE id = ?").get(id) as any;
    if (post && Number(post.user_id) === userId) {
      db.prepare("DELETE FROM post_interactions WHERE post_id = ?").run(id);
      db.prepare("DELETE FROM comments WHERE post_id = ?").run(id);
      db.prepare("DELETE FROM posts WHERE id = ?").run(id);
      res.json({ success: true });
    } else {
      res.status(403).json({ success: false, message: "Unauthorized" });
    }
  });

  app.get("/api/feed/following", (req, res) => {
    const { userId } = req.query;
    const posts = db.prepare(`
      SELECT posts.*, users.handle, users.name, users.avatar_url,
      (SELECT COUNT(*) FROM post_interactions WHERE post_id = posts.id AND type = 'like') as likes_count,
      (SELECT COUNT(*) FROM post_interactions WHERE post_id = posts.id AND type = 'dislike') as dislikes_count,
      (SELECT COUNT(*) FROM comments WHERE post_id = posts.id) as comments_count,
      (SELECT 1 FROM post_interactions WHERE post_id = posts.id AND user_id = ? AND type = 'save') as is_saved,
      (SELECT type FROM post_interactions WHERE post_id = posts.id AND user_id = ? AND type IN ('like', 'dislike')) as user_interaction
      FROM posts 
      JOIN users ON posts.user_id = users.id 
      JOIN follows ON follows.following_id = posts.user_id
      WHERE follows.follower_id = ?
      ORDER BY posts.created_at DESC
    `).all(userId || 0, userId || 0, userId || 0);
    res.json(posts);
  });

  app.get("/api/posts/:id/comments", (req, res) => {
    const { id } = req.params;
    const comments = db.prepare(`
      SELECT comments.*, users.handle, users.name, users.avatar_url 
      FROM comments 
      JOIN users ON comments.user_id = users.id 
      WHERE post_id = ? 
      ORDER BY created_at ASC
    `).all(id);
    res.json(comments);
  });

  app.post("/api/posts/:id/comments", (req, res) => {
    const { id } = req.params;
    const { userId, content } = req.body;
    const result = db.prepare("INSERT INTO comments (user_id, post_id, content) VALUES (?, ?, ?)")
      .run(userId, id, content);
    const comment = db.prepare(`
      SELECT comments.*, users.handle, users.name, users.avatar_url 
      FROM comments 
      JOIN users ON comments.user_id = users.id 
      WHERE comments.id = ?
    `).get(result.lastInsertRowid) as any;

    const post = db.prepare("SELECT user_id FROM posts WHERE id = ?").get(id) as any;
    if (post) createNotification(post.user_id, userId, 'comment', Number(id), content);

    res.json(comment);
  });

  app.get("/api/posts/saved", (req, res) => {
    const { userId } = req.query;
    const posts = db.prepare(`
      SELECT posts.*, users.handle, users.name, users.avatar_url,
      (SELECT COUNT(*) FROM post_interactions WHERE post_id = posts.id AND type = 'like') as likes_count,
      (SELECT type FROM post_interactions WHERE post_id = posts.id AND user_id = ? AND type IN ('like', 'dislike')) as user_interaction,
      1 as is_saved
      FROM posts 
      JOIN users ON posts.user_id = users.id 
      JOIN post_interactions pi ON pi.post_id = posts.id
      WHERE pi.user_id = ? AND pi.type = 'save'
      ORDER BY pi.created_at DESC
    `).all(userId, userId);
    res.json(posts);
  });

  app.post("/api/posts", (req, res) => {
    const { userId, content, imageUrl, isGenAi } = req.body;
    const result = db.prepare("INSERT INTO posts (user_id, content, image_url, is_gen_ai) VALUES (?, ?, ?, ?)")
      .run(userId, content, imageUrl, isGenAi ? 1 : 0);
    const post = db.prepare("SELECT * FROM posts WHERE id = ?").get(result.lastInsertRowid) as any;
    
    // Notify followers
    const followers = db.prepare("SELECT follower_id FROM follows WHERE following_id = ?").all(userId);
    followers.forEach((f: any) => {
      createNotification(f.follower_id, userId, 'post', post.id, content);
    });

    res.json(post);
  });

  // Messaging Endpoints
  app.get("/api/conversations/:userId", (req, res) => {
    const { userId } = req.params;
    // Get users the current user has messaged with OR follows
    const conversations = db.prepare(`
      SELECT DISTINCT u.*, 
      (SELECT content FROM messages 
       WHERE (sender_id = ? AND receiver_id = u.id) OR (sender_id = u.id AND receiver_id = ?)
       ORDER BY created_at DESC LIMIT 1) as last_message,
      (SELECT created_at FROM messages 
       WHERE (sender_id = ? AND receiver_id = u.id) OR (sender_id = u.id AND receiver_id = ?)
       ORDER BY created_at DESC LIMIT 1) as last_message_at
      FROM users u
      LEFT JOIN messages m ON (m.sender_id = ? AND m.receiver_id = u.id) OR (m.sender_id = u.id AND m.receiver_id = ?)
      LEFT JOIN follows f ON (f.follower_id = ? AND f.following_id = u.id)
      WHERE u.id != ? AND (m.id IS NOT NULL OR f.follower_id IS NOT NULL)
      ORDER BY last_message_at DESC
    `).all(userId, userId, userId, userId, userId, userId, userId, userId);
    res.json(conversations);
  });

  app.get("/api/messages/:userId/:otherUserId", (req, res) => {
    const { userId, otherUserId } = req.params;
    const messages = db.prepare(`
      SELECT * FROM messages 
      WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
      ORDER BY created_at ASC
    `).all(userId, otherUserId, otherUserId, userId);
    res.json(messages);
  });

  app.post("/api/messages", (req, res) => {
    const { senderId, receiverId, content } = req.body;
    const result = db.prepare("INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)")
      .run(senderId, receiverId, content);
    const message = db.prepare("SELECT * FROM messages WHERE id = ?").get(result.lastInsertRowid) as any;
    createNotification(receiverId, senderId, 'message', undefined, content);
    res.json(message);
  });

  app.get("/api/users/suggested", (req, res) => {
    const userId = Number(req.query.userId) || 0;
    const users = db.prepare(`
      SELECT u.*, 
      (SELECT status FROM follows WHERE follower_id = ? AND following_id = u.id) as follow_status
      FROM users u 
      WHERE u.id != ?
      AND NOT EXISTS (SELECT 1 FROM follows WHERE follower_id = ? AND following_id = u.id)
      ORDER BY RANDOM()
      LIMIT 10
    `).all(userId, userId, userId);
    res.json(users);
  });

  app.post("/api/users/:id/follow", (req, res) => {
    const { id } = req.params;
    const { userId } = req.body;
    try {
      const targetUser = db.prepare("SELECT is_private FROM users WHERE id = ?").get(id) as any;
      const existing = db.prepare("SELECT * FROM follows WHERE follower_id = ? AND following_id = ?").get(userId, id) as any;
      
      if (existing) {
        db.prepare("DELETE FROM follows WHERE follower_id = ? AND following_id = ?").run(userId, id);
        res.json({ success: true, action: 'unfollowed' });
      } else {
        const status = targetUser?.is_private ? 0 : 1;
        db.prepare("INSERT INTO follows (follower_id, following_id, status) VALUES (?, ?, ?)").run(userId, id, status);
        createNotification(Number(id), userId, status === 0 ? 'follow_request' : 'follow');
        res.json({ success: true, action: status === 0 ? 'requested' : 'followed' });
      }
    } catch (e: any) {
      res.status(400).json({ success: false, message: e.message });
    }
  });

  app.post("/api/follows/:followerId/:followingId/approve", (req, res) => {
    const { followerId, followingId } = req.params;
    db.prepare("UPDATE follows SET status = 1 WHERE follower_id = ? AND following_id = ?").run(followerId, followingId);
    // Delete the follow request notification
    db.prepare("DELETE FROM notifications WHERE user_id = ? AND actor_id = ? AND type = 'follow_request'").run(followingId, followerId);
    createNotification(Number(followerId), Number(followingId), 'follow_accepted');
    res.json({ success: true });
  });

  app.post("/api/follows/:followerId/:followingId/deny", (req, res) => {
    const { followerId, followingId } = req.params;
    db.prepare("DELETE FROM follows WHERE follower_id = ? AND following_id = ?").run(followerId, followingId);
    // Delete the follow request notification
    db.prepare("DELETE FROM notifications WHERE user_id = ? AND actor_id = ? AND type = 'follow_request'").run(followingId, followerId);
    res.json({ success: true });
  });

  app.get("/api/users/:id/followers", (req, res) => {
    const { id } = req.params;
    const followers = db.prepare(`
      SELECT u.*, f.status 
      FROM users u 
      JOIN follows f ON u.id = f.follower_id 
      WHERE f.following_id = ?
    `).all(id);
    res.json(followers);
  });

  app.get("/api/users/:id/following", (req, res) => {
    const { id } = req.params;
    const following = db.prepare(`
      SELECT u.*, f.status 
      FROM users u 
      JOIN follows f ON u.id = f.following_id 
      WHERE f.follower_id = ?
    `).all(id);
    res.json(following);
  });

  app.delete("/api/users/:id/followers/:followerId", (req, res) => {
    const { id, followerId } = req.params;
    db.prepare("DELETE FROM follows WHERE follower_id = ? AND following_id = ?").run(followerId, id);
    res.json({ success: true });
  });

  app.patch("/api/users/:id", (req, res) => {
    const { id } = req.params;
    const { name, bio, avatar_url, banner_url, is_private } = req.body;
    db.prepare("UPDATE users SET name = ?, bio = ?, avatar_url = ?, banner_url = ?, is_private = ? WHERE id = ?")
      .run(name, bio, avatar_url, banner_url, is_private ? 1 : 0, id);
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(id);
    res.json({ success: true, user });
  });

  app.get("/api/users/id/:id", (req, res) => {
  const user = db.prepare("SELECT id, name, handle, avatar_url FROM users WHERE id = ?").get(req.params.id);
  if (user) {
    res.json(user);
  } else {
    res.status(404).json({ error: "User not found" });
  }
});

app.get("/api/users/:handle", (req, res) => {
    const { handle } = req.params;
    const { userId } = req.query;
    const user = db.prepare(`
      SELECT u.*, 
      (SELECT COUNT(*) FROM follows WHERE following_id = u.id AND status = 1) as followers_count,
      (SELECT COUNT(*) FROM follows WHERE follower_id = u.id AND status = 1) as following_count,
      (SELECT status FROM follows WHERE follower_id = ? AND following_id = u.id) as follow_status
      FROM users u 
      WHERE handle = ?
    `).get(userId || 0, handle);
    if (user) {
      res.json(user);
    } else {
      res.status(404).json({ message: "User not found" });
    }
  });

  app.get("/api/users/:handle/posts", (req, res) => {
    const { handle } = req.params;
    const { userId } = req.query;
    const currentUserId = Number(userId) || 0;
    
    // Check if user is private and if current user is following
    const targetUser = db.prepare("SELECT id, is_private FROM users WHERE handle = ?").get(handle);
    if (!targetUser) return res.status(404).json({ error: "User not found" });

    const isFollowing = db.prepare("SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ? AND status = 1").get(currentUserId, targetUser.id);
    
    if (targetUser.is_private && targetUser.id !== currentUserId && !isFollowing) {
      return res.json([]); // Return empty array if private and not following
    }

    const posts = db.prepare(`
      SELECT posts.*, users.handle, users.name, users.avatar_url,
      (SELECT COUNT(*) FROM post_interactions WHERE post_id = posts.id AND type = 'like') as likes_count,
      (SELECT COUNT(*) FROM post_interactions WHERE post_id = posts.id AND type = 'dislike') as dislikes_count,
      (SELECT COUNT(*) FROM comments WHERE post_id = posts.id) as comments_count,
      (SELECT type FROM post_interactions WHERE post_id = posts.id AND user_id = ? AND type IN ('like', 'dislike')) as user_interaction,
      (SELECT 1 FROM post_interactions WHERE post_id = posts.id AND user_id = ? AND type = 'save') as is_saved
      FROM posts 
      JOIN users ON posts.user_id = users.id 
      WHERE users.handle = ?
      ORDER BY posts.created_at DESC
    `).all(currentUserId, currentUserId, handle);
    res.json(posts);
  });

  app.get("/api/notifications/:userId", (req, res) => {
    const { userId } = req.params;
    const notifications = db.prepare(`
      SELECT n.*, u.name as actor_name, u.avatar_url as actor_avatar, u.handle as actor_handle
      FROM notifications n
      JOIN users u ON n.actor_id = u.id
      WHERE n.user_id = ?
      ORDER BY n.created_at DESC
      LIMIT 50
    `).all(userId);
    res.json(notifications);
  });

  app.post("/api/notifications/:userId/read", (req, res) => {
    const { userId } = req.params;
    db.prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?").run(userId);
    res.json({ success: true });
  });

  // Vite middleware for development
  app.post("/api/upload", upload.single('file'), (req: any, res) => {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });
    const url = `/uploads/${req.file.filename}`;
    res.json({ url });
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
