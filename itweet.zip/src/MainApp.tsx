import React, { useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { Home, Search, Bell, Mail, Bookmark, User, Settings, Moon, Sun, Send, Image as ImageIcon, Gift, BarChart2, Smile, MoreHorizontal, Verified, Repeat, Heart, ArrowLeft, Info, Phone, PlusCircle, LogOut, ChevronDown, ThumbsDown, Trash2, MessageCircle, UserPlus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';

// --- Shared Components ---

const renderContent = (content: string, onProfileClick: (handle: string) => void) => {
  if (!content) return null;
  const parts = content.split(/(@\w+)/g);
  return parts.map((part, i) => {
    if (part.startsWith('@')) {
      const handle = part.slice(1);
      return (
        <span
          key={i}
          className="text-primary hover:underline cursor-pointer font-semibold"
          onClick={(e) => {
            e.stopPropagation();
            onProfileClick(handle);
          }}
        >
          {part}
        </span>
      );
    }
    return part;
  });
};

const Sidebar = ({ activeTab, onTabChange }: { activeTab: string, onTabChange: (tab: string) => void }) => {
  const navItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'search', icon: Search, label: 'Search' },
    { id: 'notifications', icon: Bell, label: 'Notifications' },
    { id: 'messages', icon: Mail, label: 'Messages' },
    { id: 'save', icon: Bookmark, label: 'Save' },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <aside className="h-screen w-72 sticky top-0 left-0 flex flex-col bg-surface py-4 px-6 hidden md:flex border-r border-outline-variant/10">
      <div className="text-2xl font-black text-primary mb-8 px-4 tracking-tighter">iTweet</div>
      <nav className="flex-1 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`flex items-center gap-4 py-3 px-4 w-full rounded-full transition-all duration-200 ${
              activeTab === item.id ? 'text-primary font-bold bg-surface-container' : 'text-gray-400 font-medium hover:bg-surface-container'
            }`}
          >
            <item.icon className={`w-6 h-6 ${activeTab === item.id ? 'fill-current' : ''}`} />
            <span className="text-base font-semibold tracking-wide">{item.label}</span>
          </button>
        ))}
      </nav>
    </aside>
  );
};

const RightSidebar = ({ onProfileClick }: { onProfileClick: (handle: string) => void }) => {
  const { user } = useAuth();
  const [suggestedUsers, setSuggestedUsers] = useState<any[]>([]);

  const fetchSuggested = () => {
    fetch(`/api/users/suggested?userId=${user?.id}`).then(res => res.json()).then(setSuggestedUsers);
  };

  useEffect(() => {
    if (user) fetchSuggested();
  }, [user]);

  const handleFollow = async (targetId: number) => {
    const res = await fetch(`/api/users/${targetId}/follow`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user?.id }),
    });
    if (res.ok) {
      const data = await res.json();
      toast.success(data.action === 'requested' ? "Follow request sent" : "Follow status updated");
      fetchSuggested();
    }
  };

  const getFollowButtonText = (status: number | null) => {
    if (status === 1) return 'Following';
    if (status === 0) return 'Requested';
    return 'Follow';
  };

  return (
    <aside className="w-80 p-6 hidden lg:flex flex-col gap-6 sticky top-0 h-screen overflow-y-auto custom-scrollbar">
      <div className="bg-surface-container-low p-6 rounded-2xl flex flex-col gap-4">
        <h3 className="text-xl font-extrabold tracking-tight text-on-surface">Subscribe to Premium</h3>
        <p className="text-sm font-medium leading-relaxed text-on-surface-variant">Subscribe to unlock new features and if eligible, receive a share of ads revenue.</p>
        <button className="bg-primary text-on-primary font-bold py-2 px-6 rounded-full w-fit hover:opacity-90 transition-opacity">Subscribe</button>
      </div>

      <div className="bg-surface-container-low rounded-2xl overflow-hidden">
        <h3 className="text-xl font-extrabold tracking-tight p-6 pb-2 text-on-surface">Who to follow</h3>
        <div className="flex flex-col">
          {suggestedUsers.map((u) => (
            <div 
              key={u.id} 
              onClick={() => onProfileClick(u.handle)}
              className="px-6 py-4 flex items-center justify-between hover:bg-surface-container-high transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-3 min-w-0">
                <img src={u.avatar_url} className="w-10 h-10 rounded-full object-cover" />
                <div className="min-w-0">
                  <p className="font-bold text-sm truncate text-on-surface">{u.name}</p>
                  <p className="text-xs text-on-surface-variant truncate">@{u.handle}</p>
                </div>
              </div>
              <button 
                onClick={(e) => { e.stopPropagation(); handleFollow(u.id); }}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${u.follow_status !== null ? 'bg-surface-container-high text-on-surface border border-outline-variant' : 'bg-on-surface text-surface'}`}
              >
                {getFollowButtonText(u.follow_status)}
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-surface-container-low rounded-2xl overflow-hidden">
        <h3 className="text-xl font-extrabold tracking-tight p-6 pb-2">What's Happening</h3>
        <div className="flex flex-col">
          {[
            { category: 'Trending in Tech', title: '#ArtificialIntelligence', posts: '45.2K' },
            { category: 'Entertainment · Trending', title: 'Obsidian Design', posts: '12.8K' },
            { category: 'Global News', title: '#DigitalGalleries', posts: '8.4K' },
          ].map((trend, i) => (
            <div key={i} className="px-6 py-4 hover:bg-surface-container-high transition-colors cursor-pointer">
              <p className="text-xs text-on-surface-variant uppercase tracking-widest font-medium">{trend.category}</p>
              <p className="font-bold text-on-surface mt-0.5">{trend.title}</p>
              <p className="text-xs text-on-surface-variant mt-1">{trend.posts} posts</p>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
};

const SuggestedProfilesHorizontal = ({ onProfileClick }: { onProfileClick: (handle: string) => void }) => {
  const { user } = useAuth();
  const [suggestedUsers, setSuggestedUsers] = useState<any[]>([]);

  const fetchSuggested = () => {
    fetch(`/api/users/suggested?userId=${user?.id}`).then(res => res.json()).then(setSuggestedUsers);
  };

  useEffect(() => {
    if (user) fetchSuggested();
  }, [user]);

  const handleFollow = async (targetId: number) => {
    const res = await fetch(`/api/users/${targetId}/follow`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user?.id }),
    });
    if (res.ok) {
      const data = await res.json();
      toast.success(data.action === 'requested' ? "Follow request sent" : "Follow status updated");
      fetchSuggested();
    }
  };

  if (suggestedUsers.length === 0) return null;

  return (
    <div className="p-6 border-b border-outline-variant/10">
      <h3 className="text-lg font-bold mb-4">Suggested Profiles</h3>
      <div className="flex gap-4 overflow-x-auto pb-4 custom-scrollbar no-scrollbar">
        {suggestedUsers.map((u) => (
          <div 
            key={u.id} 
            onClick={() => onProfileClick(u.handle)}
            className="flex-shrink-0 w-40 bg-surface-container-low p-4 rounded-2xl border border-outline-variant/10 hover:bg-surface-container-high transition-colors cursor-pointer flex flex-col items-center text-center"
          >
            <img src={u.avatar_url} className="w-16 h-16 rounded-full object-cover mb-3" />
            <p className="font-bold text-sm truncate w-full">{u.name}</p>
            <p className="text-xs text-on-surface-variant truncate w-full mb-3">@{u.handle}</p>
            <button 
              onClick={(e) => { e.stopPropagation(); handleFollow(u.id); }}
              className={`w-full py-1.5 rounded-full text-xs font-bold transition-all ${u.follow_status !== null ? 'bg-surface-container-high text-on-surface border border-outline-variant' : 'bg-on-surface text-surface'}`}
            >
              {u.follow_status === 1 ? 'Following' : u.follow_status === 0 ? 'Requested' : 'Follow'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

// --- Page Components ---

const Post: React.FC<{ post: any, onUpdate: () => void, onProfileClick: (handle: string) => void }> = ({ post, onUpdate, onProfileClick }) => {
  const { user } = useAuth();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<any[]>([]);
  const [newComment, setNewComment] = useState('');

  const handleInteract = async (type: string) => {
    const res = await fetch(`/api/posts/${post.id}/interact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user?.id, type }),
    });
    if (res.ok) {
      toast.success(`${type.charAt(0).toUpperCase() + type.slice(1)} status updated`);
      onUpdate();
    }
  };

  const handleDelete = async () => {
    if (!user?.id) return;
    const res = await fetch(`/api/posts/${post.id}?userId=${user.id}`, {
      method: 'DELETE',
    });
    if (res.ok) {
      toast.success("Post deleted");
      onUpdate();
    } else {
      const data = await res.json();
      toast.error(data.message || "Failed to delete post");
    }
  };

  const fetchComments = async () => {
    const res = await fetch(`/api/posts/${post.id}/comments`);
    const data = await res.json();
    setComments(data);
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) return;
    const res = await fetch(`/api/posts/${post.id}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user?.id, content: newComment }),
    });
    if (res.ok) {
      toast.success("Comment added");
      setNewComment('');
      fetchComments();
      onUpdate();
    }
  };

  useEffect(() => {
    if (showComments) fetchComments();
  }, [showComments]);

  return (
    <article className="p-6 hover:bg-surface-container-low transition-colors cursor-pointer group relative">
      <div className="flex gap-4">
        <img 
          alt={post.name} 
          className="w-12 h-12 rounded-full object-cover cursor-pointer hover:opacity-80 transition-opacity" 
          src={post.avatar_url} 
          onClick={(e) => { e.stopPropagation(); onProfileClick(post.handle); }}
        />
        <div className="flex-1">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-1.5 min-w-0">
              <span 
                className="font-bold hover:underline truncate cursor-pointer text-on-surface"
                onClick={(e) => { e.stopPropagation(); onProfileClick(post.handle); }}
              >
                {post.name}
              </span>
              {post.is_gen_ai === 1 && <Verified className="w-4 h-4 text-primary fill-current shrink-0" />}
              <span 
                className="text-on-surface-variant text-sm truncate cursor-pointer"
                onClick={(e) => { e.stopPropagation(); onProfileClick(post.handle); }}
              >
                @{post.handle}
              </span>
              <span className="text-on-surface-variant text-sm shrink-0">· 2h</span>
            </div>
            <div className="relative">
              <button onClick={(e) => { e.stopPropagation(); setIsDropdownOpen(!isDropdownOpen); }}>
                <MoreHorizontal className="text-on-surface-variant w-5 h-5 hover:text-primary transition-colors" />
              </button>
              <AnimatePresence>
                {isDropdownOpen && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setIsDropdownOpen(false)} />
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="absolute right-0 mt-2 w-48 bg-surface-container-high rounded-xl shadow-xl border border-outline-variant/20 z-20 py-2"
                    >
                      {user?.id === post.user_id && (
                        <button 
                          onClick={(e) => { e.stopPropagation(); handleDelete(); setIsDropdownOpen(false); }}
                          className="w-full flex items-center gap-3 px-4 py-2 text-sm font-semibold text-red-500 hover:bg-red-500/10 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                          Delete Post
                        </button>
                      )}
                      {user?.id !== post.user_id && (
                        <div className="px-4 py-2 text-xs text-on-surface-variant font-medium">
                          No actions available
                        </div>
                      )}
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
          </div>
          <p className="text-lg text-on-surface mb-4 leading-relaxed">
            {renderContent(post.content, onProfileClick)}
          </p>
          {post.image_url && (
            <div className="rounded-xl overflow-hidden mb-4 border border-outline-variant/15">
              <img alt="Post" className="w-full h-auto object-cover aspect-video" src={post.image_url} />
            </div>
          )}
          <div className="flex justify-between max-w-md text-on-surface-variant">
            <button 
              onClick={(e) => { e.stopPropagation(); handleInteract('like'); }}
              className={`flex items-center gap-2 transition-colors ${post.user_interaction === 'like' ? 'text-primary' : 'hover:text-primary'}`}
            >
              <Heart className={`w-4 h-4 ${post.user_interaction === 'like' ? 'fill-current' : ''}`} />
              <span className="text-xs">{post.likes_count || 0}</span>
            </button>
            <button 
              onClick={(e) => { e.stopPropagation(); handleInteract('dislike'); }}
              className={`flex items-center gap-2 transition-colors ${post.user_interaction === 'dislike' ? 'text-red-500' : 'hover:text-red-500'}`}
            >
              <ThumbsDown className={`w-4 h-4 ${post.user_interaction === 'dislike' ? 'fill-current' : ''}`} />
              <span className="text-xs">{post.dislikes_count || 0}</span>
            </button>
            <button 
              onClick={(e) => { e.stopPropagation(); setShowComments(!showComments); }}
              className="flex items-center gap-2 hover:text-primary transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span className="text-xs">{post.comments_count || 0}</span>
            </button>
            <button 
              onClick={(e) => { e.stopPropagation(); handleInteract('save'); }}
              className={`flex items-center gap-2 transition-colors ${post.is_saved ? 'text-primary' : 'hover:text-primary'}`}
            >
              <Bookmark className={`w-4 h-4 ${post.is_saved ? 'fill-primary text-primary' : ''}`} />
            </button>
          </div>

          {showComments && (
            <div className="mt-4 pt-4 border-t border-outline-variant/10 space-y-4" onClick={(e) => e.stopPropagation()}>
              <div className="flex gap-2">
                <input 
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Post your reply"
                  className="flex-1 bg-surface-container-high rounded-full px-4 py-2 text-sm focus:ring-1 focus:ring-primary outline-none"
                />
                <button 
                  onClick={handleAddComment}
                  className="bg-primary text-on-primary px-4 py-2 rounded-full text-sm font-bold"
                >
                  Reply
                </button>
              </div>
              <div className="space-y-4">
                {comments.map(comment => (
                  <div key={comment.id} className="flex gap-3">
                    <img src={comment.avatar_url} className="w-8 h-8 rounded-full object-cover" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm">{comment.name}</span>
                        <span className="text-on-surface-variant text-xs">@{comment.handle}</span>
                      </div>
                      <p className="text-sm text-on-surface">{comment.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </article>
  );
};const NotificationsPage = () => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchNotifications = () => {
    fetch(`/api/notifications/${user?.id}`).then(res => res.json()).then(data => {
      setNotifications(data);
      setIsLoading(false);
      fetch(`/api/notifications/${user?.id}/read`, { method: 'POST' });
    });
  };

  useEffect(() => {
    if (user) fetchNotifications();
  }, [user]);

  if (isLoading) return <div className="flex-1 flex items-center justify-center"><div className="animate-spin rounded-full h-8 w-8 border-t-2 border-primary"></div></div>;

  const getNotificationText = (n: any) => {
    switch (n.type) {
      case 'like': return 'liked your post';
      case 'comment': return 'commented on your post';
      case 'follow': return 'started following you';
      case 'follow_request': return 'requested to follow you';
      case 'follow_accepted': return 'accepted your follow request';
      case 'message': return 'sent you a message';
      case 'post': return 'posted a new update';
      default: return 'interacted with you';
    }
  };

  const handleApprove = async (e: React.MouseEvent, n: any) => {
    e.stopPropagation();
    const res = await fetch(`/api/follows/${n.actor_id}/${n.user_id}/approve`, { method: 'POST' });
    if (res.ok) {
      toast.success("Follow request approved");
      fetchNotifications();
    }
  };

  const handleDeny = async (e: React.MouseEvent, n: any) => {
    e.stopPropagation();
    const res = await fetch(`/api/follows/${n.actor_id}/${n.user_id}/deny`, { method: 'POST' });
    if (res.ok) {
      toast.success("Follow request denied");
      fetchNotifications();
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'like': return <Heart className="w-5 h-5 text-primary fill-current" />;
      case 'comment': return <MessageCircle className="w-5 h-5 text-primary" />;
      case 'follow': return <UserPlus className="w-5 h-5 text-primary" />;
      case 'follow_request': return <UserPlus className="w-5 h-5 text-primary animate-pulse" />;
      case 'follow_accepted': return <UserPlus className="w-5 h-5 text-green-500" />;
      case 'message': return <Mail className="w-5 h-5 text-primary" />;
      case 'post': return <PlusCircle className="w-5 h-5 text-primary" />;
      default: return <Bell className="w-5 h-5 text-primary" />;
    }
  };

  return (
    <div className="flex-1 max-w-2xl min-h-screen bg-surface border-x border-outline-variant/15">
      <header className="bg-surface/70 backdrop-blur-xl sticky top-0 z-50 border-b border-outline-variant/10 px-6 py-4">
        <h1 className="text-xl font-black tracking-tight">Notifications</h1>
      </header>
      <div className="divide-y divide-outline-variant/10">
        {notifications.length > 0 ? (
          notifications.map((n) => (
            <div key={n.id} className={`p-6 flex gap-4 hover:bg-surface-container-low transition-colors cursor-pointer ${!n.is_read ? 'bg-primary/5' : ''}`}>
              <div className="mt-1">{getNotificationIcon(n.type)}</div>
              <div className="flex-1 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <img src={n.actor_avatar} className="w-8 h-8 rounded-full object-cover" />
                    <p className="text-sm">
                      <span className="font-bold">{n.actor_name}</span>{' '}
                      <span className="text-on-surface-variant">{getNotificationText(n)}</span>
                    </p>
                  </div>
                  {n.type === 'follow_request' && (
                    <div className="flex gap-2">
                      <button 
                        onClick={(e) => handleApprove(e, n)}
                        className="bg-primary text-on-primary px-4 py-1 rounded-full text-xs font-bold hover:opacity-90 transition-opacity"
                      >
                        Approve
                      </button>
                      <button 
                        onClick={(e) => handleDeny(e, n)}
                        className="bg-surface-container-high text-on-surface px-4 py-1 rounded-full text-xs font-bold border border-outline-variant hover:bg-surface-container transition-colors"
                      >
                        Deny
                      </button>
                    </div>
                  )}
                </div>
                {n.content && (
                  <p className="text-sm text-on-surface-variant line-clamp-2 bg-surface-container p-3 rounded-xl border border-outline-variant/10 italic">
                    "{n.content}"
                  </p>
                )}
                <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-widest">
                  {new Date(n.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center px-10">
            <Bell className="w-16 h-16 text-primary/20 mb-4" />
            <h3 className="text-xl font-bold mb-2">No notifications yet</h3>
            <p className="text-on-surface-variant">When people interact with you or your posts, you'll see it here.</p>
          </div>
        )}
      </div>
    </div>
  );
};

const FeedPage = ({ onProfileClick }: { onProfileClick: (handle: string) => void }) => {
  const [posts, setPosts] = useState<any[]>([]);
  const [newPostContent, setNewPostContent] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [activeFeedTab, setActiveFeedTab] = useState<'for-you' | 'following'>('for-you');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const emojis = ['😊', '😂', '🔥', '❤️', '👍', '🙌', '✨', '🚀', '🤔', '👀', '💯', '✅'];

  const addEmoji = (emoji: string) => {
    setNewPostContent(prev => prev + emoji);
    setShowEmojiPicker(false);
  };
  const { user } = useAuth();
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const fetchFeed = () => {
    const endpoint = activeFeedTab === 'for-you' ? '/api/feed' : '/api/feed/following';
    fetch(`${endpoint}?userId=${user?.id}`).then(res => res.json()).then(setPosts);
  };

  useEffect(() => {
    if (user) fetchFeed();
  }, [user, activeFeedTab]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePost = async () => {
    if (!newPostContent.trim() && !selectedImage) return;
    const res = await fetch('/api/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: user?.id,
        content: newPostContent,
        imageUrl: selectedImage,
        isGenAi: false
      }),
    });
    if (res.ok) {
      setNewPostContent('');
      setSelectedImage(null);
      fetchFeed();
      toast.success("Post published!");
    }
  };

  return (
    <div className="flex-1 max-w-2xl min-h-screen bg-surface border-x border-outline-variant/15">
      <header className="bg-surface/70 backdrop-blur-xl sticky top-0 z-50 border-b border-outline-variant/10">
        <div className="flex justify-between items-center w-full px-6 py-4">
          <h1 className="text-lg font-bold text-primary">Home</h1>
          <BarChart2 className="text-primary w-5 h-5" />
        </div>
        <div className="flex w-full">
          <button 
            onClick={() => setActiveFeedTab('for-you')}
            className={`flex-1 py-4 text-center font-bold transition-all ${activeFeedTab === 'for-you' ? 'text-primary border-b-4 border-primary' : 'text-on-surface-variant hover:bg-surface-container'}`}
          >
            For You
          </button>
          <button 
            onClick={() => setActiveFeedTab('following')}
            className={`flex-1 py-4 text-center font-bold transition-all ${activeFeedTab === 'following' ? 'text-primary border-b-4 border-primary' : 'text-on-surface-variant hover:bg-surface-container'}`}
          >
            Following
          </button>
        </div>
      </header>

      <div className="p-6 border-b border-outline-variant/10">
        <div className="flex gap-4">
          <img alt="User" className="w-12 h-12 rounded-full object-cover" src={user?.avatar_url || ''} />
          <div className="flex-1">
            <textarea
              className="w-full bg-transparent border-none focus:ring-0 text-lg text-on-surface placeholder-on-surface-variant resize-none min-h-[100px]"
              placeholder="What's sparking your thoughts?"
              value={newPostContent}
              maxLength={480}
              onChange={(e) => setNewPostContent(e.target.value)}
            />
            {selectedImage && (
              <div className="relative mt-2 rounded-xl overflow-hidden border border-outline-variant/20">
                <img src={selectedImage} alt="Selected" className="w-full h-auto max-h-80 object-cover" />
                <button 
                  onClick={() => setSelectedImage(null)}
                  className="absolute top-2 right-2 p-1 bg-surface/80 rounded-full text-on-surface hover:bg-surface transition-colors"
                >
                  <ArrowLeft className="w-4 h-4 rotate-90" />
                </button>
              </div>
            )}
            <div className="flex items-center justify-between mt-4">
              <div className="flex gap-2 text-primary relative">
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={handleImageSelect}
                />
                <ImageIcon className="w-5 h-5 cursor-pointer hover:bg-primary/10 rounded-full p-0.5 transition-colors" onClick={() => fileInputRef.current?.click()} />
                <Gift className="w-5 h-5 cursor-pointer hover:bg-primary/10 rounded-full p-0.5 transition-colors" onClick={() => toast.info("Gifts coming soon!")} />
                <BarChart2 className="w-5 h-5 cursor-pointer hover:bg-primary/10 rounded-full p-0.5 transition-colors" onClick={() => toast.info("Polls coming soon!")} />
                <div className="relative">
                  <Smile className="w-5 h-5 cursor-pointer hover:bg-primary/10 rounded-full p-0.5 transition-colors" onClick={() => setShowEmojiPicker(!showEmojiPicker)} />
                  {showEmojiPicker && (
                    <div className="absolute top-10 left-0 z-50 bg-surface-container-high p-4 rounded-2xl shadow-2xl border border-outline-variant/20 grid grid-cols-6 gap-3 min-w-[240px]">
                      {emojis.map(emoji => (
                        <button key={emoji} onClick={() => addEmoji(emoji)} className="text-2xl hover:scale-125 transition-transform p-1 rounded-lg hover:bg-surface-container transition-colors">{emoji}</button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-bold ${newPostContent.length > 450 ? 'text-red-500' : 'text-on-surface-variant'}`}>
                    {newPostContent.length} / 480
                  </span>
                  <div className="relative w-8 h-8 flex items-center justify-center">
                    <svg className="w-full h-full -rotate-90">
                      <circle
                        cx="16"
                        cy="16"
                        r="14"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        className="text-outline-variant"
                      />
                      <circle
                        cx="16"
                        cy="16"
                        r="14"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeDasharray={88}
                        strokeDashoffset={88 - (Math.min(newPostContent.length, 480) / 480) * 88}
                        className={`${newPostContent.length > 450 ? 'text-red-500' : 'text-primary'} transition-all duration-300`}
                      />
                    </svg>
                    {newPostContent.length > 450 && (
                      <span className="absolute text-[10px] font-bold text-red-500">
                        {480 - newPostContent.length}
                      </span>
                    )}
                  </div>
                </div>
                <button 
                  onClick={handlePost}
                  disabled={(!newPostContent.trim() && !selectedImage) || newPostContent.length > 480}
                  className="px-6 py-2 bg-primary text-on-primary font-bold rounded-full active:scale-95 transition-transform disabled:opacity-50 disabled:scale-100"
                >
                  Post
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="divide-y divide-outline-variant/10">
        {posts.length === 0 && <SuggestedProfilesHorizontal onProfileClick={onProfileClick} />}
        {posts.map((post, index) => (
          <React.Fragment key={post.id}>
            <Post post={post} onUpdate={fetchFeed} onProfileClick={onProfileClick} />
            {(index === 0 || index === 2 || (index + 1) % 5 === 0) && <SuggestedProfilesHorizontal onProfileClick={onProfileClick} />}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

const SearchPage = ({ onProfileClick }: { onProfileClick: (handle: string) => void }) => {
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<{ users: any[], posts: any[] }>({ users: [], posts: [] });
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async (q: string) => {
    setQuery(q);
    if (!q.trim()) {
      setResults({ users: [], posts: [] });
      return;
    }
    setIsSearching(true);
    const res = await fetch(`/api/search?q=${q}&userId=${user?.id}`);
    const data = await res.json();
    setResults(data);
    setIsSearching(false);
  };

  const handleFollow = async (targetId: number) => {
    const res = await fetch(`/api/users/${targetId}/follow`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user?.id }),
    });
    if (res.ok) {
      const data = await res.json();
      toast.success(data.action === 'requested' ? "Follow request sent" : "Follow status updated");
      handleSearch(query);
    }
  };

  const getFollowButtonText = (status: number | null) => {
    if (status === 1) return 'Following';
    if (status === 0) return 'Requested';
    return 'Follow';
  };

  return (
    <div className="flex-1 max-w-2xl min-h-screen bg-surface border-x border-outline-variant/15">
      <header className="bg-surface/70 backdrop-blur-xl sticky top-0 z-50 border-b border-outline-variant/10 p-4">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant w-5 h-5 group-focus-within:text-primary transition-colors" />
          <input 
            value={query}
            onChange={(e) => handleSearch(e.target.value)}
            className="w-full bg-surface-container-high border-none rounded-full py-3 pl-12 pr-6 text-on-surface placeholder:text-on-surface-variant focus:ring-1 focus:ring-primary transition-all" 
            placeholder="Search iTweet" 
            type="text" 
          />
        </div>
      </header>

      <div className="p-4">
        {results.users.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-black mb-4 px-2">People</h2>
            <div className="space-y-4">
              {results.users.map(u => (
                <div 
                  key={u.id} 
                  onClick={() => onProfileClick(u.handle)}
                  className="flex items-center justify-between p-4 hover:bg-surface-container rounded-2xl transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-4">
                    <img src={u.avatar_url} className="w-12 h-12 rounded-full object-cover" />
                    <div>
                      <p className="font-bold">{u.name}</p>
                      <p className="text-on-surface-variant text-sm">@{u.handle}</p>
                    </div>
                  </div>
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleFollow(u.id); }}
                    className={`px-6 py-1.5 rounded-full font-bold text-sm transition-all ${u.follow_status !== null ? 'bg-surface-container-high text-on-surface border border-outline-variant' : 'bg-on-surface text-surface'}`}
                  >
                    {getFollowButtonText(u.follow_status)}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {results.posts.length > 0 && (
          <div>
            <h2 className="text-xl font-black mb-4 px-2">Posts</h2>
            <div className="divide-y divide-outline-variant/10">
              {results.posts.map(post => (
                <Post key={post.id} post={post} onUpdate={() => handleSearch(query)} onProfileClick={onProfileClick} />
              ))}
            </div>
          </div>
        )}

        {!query && (
          <>
            <SuggestedProfilesHorizontal onProfileClick={onProfileClick} />
            <div className="flex flex-col items-center justify-center py-20 text-center px-10">
              <Search className="w-16 h-16 text-primary/20 mb-4" />
              <h3 className="text-xl font-bold mb-2">Search for anything</h3>
              <p className="text-on-surface-variant">Find people, posts, and conversations across iTweet.</p>
            </div>
          </>
        )}

        {query && results.users.length === 0 && results.posts.length === 0 && !isSearching && (
          <div className="text-center py-20">
            <p className="text-on-surface-variant font-medium">No results found for "{query}"</p>
          </div>
        )}
      </div>
    </div>
  );
};

const SavedPostsPage = ({ onProfileClick }: { onProfileClick: (handle: string) => void }) => {
  const { user } = useAuth();
  const [posts, setPosts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchSavedPosts = () => {
    fetch(`/api/posts/saved?userId=${user?.id}`).then(res => res.json()).then(data => {
      setPosts(data);
      setIsLoading(false);
    });
  };

  useEffect(() => {
    if (user) fetchSavedPosts();
  }, [user]);

  if (isLoading) return <div className="flex-1 flex items-center justify-center"><div className="animate-spin rounded-full h-8 w-8 border-t-2 border-primary"></div></div>;

  return (
    <div className="flex-1 max-w-2xl min-h-screen bg-surface border-x border-outline-variant/15">
      <header className="bg-surface/70 backdrop-blur-xl sticky top-0 z-50 border-b border-outline-variant/10 px-6 py-4">
        <h1 className="text-xl font-black tracking-tight">Saved Posts</h1>
      </header>
      <div className="divide-y divide-outline-variant/10">
        {posts.length > 0 ? (
          posts.map((post) => (
            <Post key={post.id} post={post} onUpdate={fetchSavedPosts} onProfileClick={onProfileClick} />
          ))
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center px-10">
            <Bookmark className="w-16 h-16 text-primary/20 mb-4" />
            <h3 className="text-xl font-bold mb-2">No saved posts yet</h3>
            <p className="text-on-surface-variant">Save posts to easily find them later. They'll appear here for your convenience.</p>
          </div>
        )}
      </div>
    </div>
  );
};

const EditProfileModal = ({ user, onClose, onUpdate }: { user: any, onClose: () => void, onUpdate: (user: any) => void }) => {
  const [formData, setFormData] = useState({
    name: user.name,
    bio: user.bio || '',
    avatar_url: user.avatar_url,
    banner_url: user.banner_url || '',
    is_private: user.is_private === 1
  });
  const [isUploading, setIsUploading] = useState(false);
  const avatarInputRef = React.useRef<HTMLInputElement>(null);
  const bannerInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: 'avatar_url' | 'banner_url') => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const formDataUpload = new FormData();
    formDataUpload.append('file', file);

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formDataUpload,
      });
      const data = await res.json();
      if (data.url) {
        setFormData(prev => ({ ...prev, [field]: data.url }));
        toast.success("Image uploaded");
      }
    } catch (error) {
      toast.error("Upload failed");
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch(`/api/users/${user.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });
    const data = await res.json();
    if (data.success) {
      onUpdate(data.user);
      onClose();
      toast.success("Profile updated");
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-surface w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border border-outline-variant/20"
      >
        <header className="px-6 py-4 border-b border-outline-variant/10 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={onClose} className="p-2 hover:bg-surface-container rounded-full transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h2 className="text-xl font-black">Edit Profile</h2>
          </div>
          <button onClick={handleSubmit} disabled={isUploading} className="bg-on-surface text-surface px-6 py-1.5 rounded-full font-bold text-sm hover:opacity-90 disabled:opacity-50">
            {isUploading ? 'Uploading...' : 'Save'}
          </button>
        </header>
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto custom-scrollbar">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Name</label>
              <input 
                className="w-full bg-surface-container-low border border-outline-variant/20 rounded-xl px-4 py-3 focus:ring-1 focus:ring-primary outline-none"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Bio</label>
              <textarea 
                className="w-full bg-surface-container-low border border-outline-variant/20 rounded-xl px-4 py-3 focus:ring-1 focus:ring-primary outline-none min-h-[100px] resize-none"
                value={formData.bio}
                onChange={e => setFormData({...formData, bio: e.target.value})}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Profile Picture</label>
              <div className="flex items-center gap-4">
                <img src={formData.avatar_url} className="w-16 h-16 rounded-full object-cover border-2 border-primary/20" />
                <input 
                  type="file" 
                  ref={avatarInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={(e) => handleFileUpload(e, 'avatar_url')} 
                />
                <button 
                  onClick={() => avatarInputRef.current?.click()}
                  className="px-4 py-2 bg-surface-container-high rounded-xl text-sm font-bold hover:bg-surface-container transition-colors"
                >
                  Change Photo
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Banner Image</label>
              <div className="space-y-3">
                {formData.banner_url && (
                  <img src={formData.banner_url} className="w-full h-24 rounded-xl object-cover border border-outline-variant/20" />
                )}
                <input 
                  type="file" 
                  ref={bannerInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={(e) => handleFileUpload(e, 'banner_url')} 
                />
                <button 
                  onClick={() => bannerInputRef.current?.click()}
                  className="w-full px-4 py-2 bg-surface-container-high rounded-xl text-sm font-bold hover:bg-surface-container transition-colors"
                >
                  {formData.banner_url ? 'Change Banner' : 'Upload Banner'}
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-surface-container-low rounded-xl border border-outline-variant/10">
              <div className="space-y-0.5">
                <p className="font-bold text-sm">Private Account</p>
                <p className="text-xs text-on-surface-variant">Only approved followers can see your posts.</p>
              </div>
              <button 
                onClick={() => setFormData({...formData, is_private: !formData.is_private})}
                className={`w-12 h-6 rounded-full relative transition-colors ${formData.is_private ? 'bg-primary' : 'bg-outline-variant'}`}
              >
                <motion.div 
                  animate={{ x: formData.is_private ? 24 : 4 }}
                  className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm"
                />
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const FollowListModal = ({ userId, type, onClose, onProfileClick, currentUserId }: { userId: number, type: 'followers' | 'following', onClose: () => void, onProfileClick: (handle: string) => void, currentUserId: number }) => {
  const [list, setList] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchList = async () => {
    const res = await fetch(`/api/users/${userId}/${type}`);
    const data = await res.json();
    setList(data);
    setIsLoading(false);
  };

  const handleRemoveFollower = async (followerId: number) => {
    const res = await fetch(`/api/users/${userId}/followers/${followerId}`, { method: 'DELETE' });
    if (res.ok) {
      toast.success("Follower removed");
      fetchList();
    }
  };

  const handleUnfollow = async (targetId: number) => {
    const res = await fetch(`/api/users/${targetId}/follow`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: currentUserId }),
    });
    if (res.ok) {
      toast.success("Unfollowed successfully");
      fetchList();
    }
  };

  useEffect(() => {
    fetchList();
  }, [userId, type]);

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-surface w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-outline-variant/20"
      >
        <header className="px-6 py-4 border-b border-outline-variant/10 flex items-center justify-between">
          <h2 className="text-xl font-black capitalize">{type}</h2>
          <button onClick={onClose} className="p-2 hover:bg-surface-container rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5 rotate-90" />
          </button>
        </header>
        <div className="max-h-[60vh] overflow-y-auto custom-scrollbar">
          {isLoading ? (
            <div className="p-10 flex justify-center"><div className="animate-spin rounded-full h-8 w-8 border-t-2 border-primary"></div></div>
          ) : list.length > 0 ? (
            <div className="divide-y divide-outline-variant/10">
              {list.map(u => (
                <div key={u.id} className="p-4 flex items-center justify-between hover:bg-surface-container-low transition-colors">
                  <div className="flex items-center gap-3 cursor-pointer" onClick={() => { onProfileClick(u.handle); onClose(); }}>
                    <img src={u.avatar_url} className="w-10 h-10 rounded-full object-cover" />
                    <div>
                      <p className="font-bold text-sm">{u.name}</p>
                      <p className="text-xs text-on-surface-variant">@{u.handle}</p>
                    </div>
                  </div>
                  {type === 'followers' && userId === currentUserId && (
                    <button 
                      onClick={() => handleRemoveFollower(u.id)}
                      className="px-4 py-1.5 border border-outline-variant rounded-full text-xs font-bold hover:bg-red-500/10 hover:text-red-500 transition-colors"
                    >
                      Remove
                    </button>
                  )}
                  {type === 'following' && userId === currentUserId && (
                    <button 
                      onClick={() => handleUnfollow(u.id)}
                      className="px-4 py-1.5 border border-outline-variant rounded-full text-xs font-bold hover:bg-red-500/10 hover:text-red-500 transition-colors"
                    >
                      Unfollow
                    </button>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="p-10 text-center text-on-surface-variant font-medium">No {type} yet.</div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

const ProfilePage = ({ handle, onProfileClick, onMessageClick }: { handle?: string, onProfileClick: (handle: string) => void, onMessageClick: (userId: number) => void }) => {
  const { user: currentUser, login } = useAuth();
  const [user, setUser] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showFollowModal, setShowFollowModal] = useState<{ show: boolean, type: 'followers' | 'following' }>({ show: false, type: 'followers' });

  const targetHandle = handle || currentUser?.handle;

  const fetchProfileData = () => {
    if (targetHandle) {
      Promise.all([
        fetch(`/api/users/${targetHandle}?userId=${currentUser?.id}`).then(res => res.json()),
        fetch(`/api/users/${targetHandle}/posts?userId=${currentUser?.id}`).then(res => res.json())
      ]).then(([userData, userPosts]) => {
        setUser(userData);
        setPosts(userPosts);
        setIsLoading(false);
      });
    }
  };

  const handleFollow = async () => {
    if (!user || !currentUser) return;
    const res = await fetch(`/api/users/${user.id}/follow`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: currentUser.id }),
    });
    const data = await res.json();
    if (res.ok) {
      toast.success(data.action === 'requested' ? "Follow request sent" : "Follow status updated");
      fetchProfileData();
    }
  };

  useEffect(() => {
    setIsLoading(true);
    fetchProfileData();
  }, [targetHandle]);

  if (isLoading) return <div className="flex-1 flex items-center justify-center"><div className="animate-spin rounded-full h-8 w-8 border-t-2 border-primary"></div></div>;
  if (!user) return <div className="flex-1 flex items-center justify-center font-bold text-on-surface-variant">User not found</div>;

  const isOwnProfile = currentUser?.id === user.id;

  return (
    <div className="flex-1 max-w-2xl min-h-screen bg-surface border-x border-outline-variant/15">
      <header className="bg-surface/70 backdrop-blur-xl sticky top-0 z-50 border-b border-outline-variant/10 px-6 py-3 flex items-center gap-8">
        <ArrowLeft className="w-5 h-5 text-on-surface cursor-pointer" onClick={() => window.history.back()} />
        <div>
          <h1 className="text-xl font-black tracking-tight text-on-surface">{user.name}</h1>
          <p className="text-xs text-on-surface-variant font-bold uppercase tracking-widest">{posts.length} Posts</p>
        </div>
      </header>

      <div className="relative">
        <div className="h-48 bg-surface-container-high relative overflow-hidden">
          {user.banner_url ? (
            <img src={user.banner_url} className="w-full h-full object-cover" />
          ) : (
            <div className="absolute inset-0 electric-gradient opacity-20"></div>
          )}
        </div>
        <div className="px-6 -mt-16 flex justify-between items-end relative z-10">
          <img alt={user.name} className="w-32 h-32 rounded-full border-4 border-surface object-cover shadow-2xl" src={user.avatar_url} />
          <div className="flex gap-2 mb-4">
            {!isOwnProfile && (
              <button 
                onClick={() => onMessageClick(user.id)}
                className="p-2 border border-outline-variant rounded-full hover:bg-surface-container transition-colors"
              >
                <Mail className="w-5 h-5" />
              </button>
            )}
            {isOwnProfile ? (
              <button 
                onClick={() => setShowEditModal(true)}
                className="px-6 py-2 border border-outline-variant rounded-full font-bold text-sm hover:bg-surface-container transition-colors text-on-surface"
              >
                Edit profile
              </button>
            ) : (
              <button 
                onClick={handleFollow}
                className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${user.follow_status !== null ? 'bg-surface-container-high text-on-surface border border-outline-variant' : 'bg-on-surface text-surface'}`}
              >
                {user.follow_status === 1 ? 'Following' : user.follow_status === 0 ? 'Requested' : 'Follow'}
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="px-6 mt-4 space-y-4 pb-8 border-b border-outline-variant/10">
        <div>
          <h2 className="text-2xl font-black tracking-tight text-on-surface">{user.name}</h2>
          <p className="text-on-surface-variant font-medium">@{user.handle}</p>
        </div>
        <p className="text-on-surface leading-relaxed">{user.bio || 'Digital architect exploring the intersection of high-fidelity design and decentralized systems. Building the future of iTweet.'}</p>
        <div className="flex gap-4 text-sm">
          <div className="flex gap-1 items-center cursor-pointer hover:underline" onClick={() => setShowFollowModal({ show: true, type: 'following' })}>
            <span className="font-bold text-on-surface">{user.following_count || 0}</span>
            <span className="text-on-surface-variant">Following</span>
          </div>
          <div className="flex gap-1 items-center cursor-pointer hover:underline" onClick={() => setShowFollowModal({ show: true, type: 'followers' })}>
            <span className="font-bold text-on-surface">{user.followers_count || 0}</span>
            <span className="text-on-surface-variant">Followers</span>
          </div>
        </div>
      </div>

      {showEditModal && (
        <EditProfileModal 
          user={user} 
          onClose={() => setShowEditModal(false)} 
          onUpdate={(updatedUser) => {
            setUser(updatedUser);
            if (isOwnProfile) login(updatedUser);
          }} 
        />
      )}

      {showFollowModal.show && (
        <FollowListModal 
          userId={user.id} 
          type={showFollowModal.type} 
          onClose={() => setShowFollowModal({ ...showFollowModal, show: false })} 
          onProfileClick={onProfileClick}
          currentUserId={currentUser?.id || 0}
        />
      )}

      <div className="flex border-b border-outline-variant/10">
        {['Posts', 'Replies', 'Highlights', 'Media', 'Likes'].map((tab, i) => (
          <button key={tab} className={`flex-1 py-4 text-sm font-bold transition-colors ${i === 0 ? 'text-on-surface border-b-4 border-primary' : 'text-on-surface-variant hover:bg-surface-container'}`}>
            {tab}
          </button>
        ))}
      </div>

      <div className="divide-y divide-outline-variant/10">
        {posts.length === 0 && <SuggestedProfilesHorizontal onProfileClick={onProfileClick} />}
        {posts.map((post, index) => (
          <React.Fragment key={post.id}>
            <Post key={post.id} post={post} onUpdate={fetchProfileData} onProfileClick={onProfileClick} />
            {(index === 0 || index === 2 || (index + 1) % 5 === 0) && <SuggestedProfilesHorizontal onProfileClick={onProfileClick} />}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

const MessagesPage = ({ initialUserId }: { initialUserId?: number }) => {
  const [conversations, setConversations] = useState<any[]>([]);
  const [activeChat, setActiveChat] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetch(`/api/conversations/${user.id}`).then(res => res.json()).then(data => {
        setConversations(data);
        if (initialUserId) {
          const existing = data.find((c: any) => c.id === initialUserId);
          if (existing) {
            setActiveChat(existing);
          } else {
            // Fetch user info for a new conversation
            fetch(`/api/users/id/${initialUserId}`).then(res => res.json()).then(u => {
              setActiveChat({
                id: u.id,
                name: u.name,
                handle: u.handle,
                avatar_url: u.avatar_url
              });
            });
          }
        }
      });
    }
  }, [user, initialUserId]);

  useEffect(() => {
    if (user && activeChat) {
      fetch(`/api/messages/${user.id}/${activeChat.id}`).then(res => res.json()).then(setMessages);
    }
  }, [user, activeChat]);

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !activeChat || !user) return;
    const res = await fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ senderId: user.id, receiverId: activeChat.id, content: newMessage }),
    });
    const data = await res.json();
    setMessages([...messages, data]);
    setNewMessage('');
  };

  return (
    <div className="flex-1 flex min-w-0 h-screen overflow-hidden border-x border-outline-variant/15">
      <section className="w-full md:w-96 flex flex-col bg-surface overflow-y-auto custom-scrollbar border-r border-outline-variant/10">
        <header className="px-6 py-4 border-b border-outline-variant/10">
          <h1 className="text-lg font-bold text-primary">Messages</h1>
        </header>
        <div className="px-6 py-4">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-outline w-4 h-4" />
            <input className="w-full bg-surface-container-lowest border-none rounded-full py-3 pl-12 pr-6 text-on-surface placeholder:text-outline focus:ring-1 focus:ring-primary transition-all" placeholder="Search direct messages" type="text" />
          </div>
        </div>
        <div className="flex flex-col">
          {conversations.map((conv) => (
            <div
              key={conv.id}
              onClick={() => setActiveChat(conv)}
              className={`px-6 py-4 flex items-center gap-4 transition-all cursor-pointer ${activeChat?.id === conv.id ? 'bg-surface-container' : 'hover:bg-surface-container-low'}`}
            >
              <img alt={conv.name} className="w-14 h-14 rounded-full object-cover" src={conv.avatar_url} />
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-baseline mb-1">
                  <h3 className="text-on-surface font-bold truncate">{conv.name}</h3>
                  <span className="text-xs text-on-surface-variant font-medium">12m</span>
                </div>
                <p className={`text-sm truncate ${activeChat?.id === conv.id ? 'text-primary font-semibold' : 'text-on-surface-variant'}`}>{conv.last_message}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="hidden md:flex flex-1 flex-col bg-surface-container-lowest">
        {activeChat ? (
          <>
            <header className="px-8 py-4 bg-surface/80 backdrop-blur-md flex items-center justify-between border-b border-outline-variant/10">
              <div className="flex items-center gap-4">
                <img alt={activeChat.name} className="w-10 h-10 rounded-full object-cover" src={activeChat.avatar_url} />
                <div>
                  <h2 className="text-on-surface font-bold text-lg leading-tight">{activeChat.name}</h2>
                  <p className="text-on-surface-variant text-xs font-medium tracking-wider">@{activeChat.handle} • Online</p>
                </div>
              </div>
              <div className="flex items-center gap-4 text-primary">
                <Phone className="w-5 h-5 cursor-pointer" />
                <Info className="w-5 h-5 cursor-pointer" />
              </div>
            </header>
            <div className="flex-1 overflow-y-auto p-8 flex flex-col gap-6 custom-scrollbar">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex items-end gap-3 max-w-[80%] ${msg.sender_id === user?.id ? 'self-end flex-row-reverse' : ''}`}>
                  {msg.sender_id !== user?.id && <img alt="Other" className="w-8 h-8 rounded-full object-cover shrink-0" src={activeChat.avatar_url} />}
                  <div className={`flex flex-col gap-1 ${msg.sender_id === user?.id ? 'items-end' : ''}`}>
                    <div className={`p-4 rounded-2xl shadow-sm ${msg.sender_id === user?.id ? 'bg-gradient-to-br from-primary to-primary-container text-on-primary rounded-br-none' : 'bg-surface-container text-on-surface rounded-bl-none'}`}>
                      {msg.content}
                    </div>
                    <span className="text-[10px] text-on-surface-variant uppercase font-semibold">10:45 AM</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-6 bg-surface/50 backdrop-blur-md">
              <div className="flex items-end gap-4 bg-surface-container-low p-3 rounded-3xl border border-outline-variant/10 focus-within:border-primary transition-all">
                <div className="flex gap-2 mb-1 pl-2 text-primary">
                  <ImageIcon className="w-6 h-6 cursor-pointer" />
                  <Gift className="w-6 h-6 cursor-pointer" />
                </div>
                <textarea
                  className="flex-1 bg-transparent border-none focus:ring-0 text-on-surface placeholder:text-outline-variant py-2.5 resize-none max-h-32 custom-scrollbar"
                  placeholder="Start a new message"
                  rows={1}
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); } }}
                />
                <button
                  onClick={handleSendMessage}
                  className="w-10 h-10 flex items-center justify-center bg-primary text-on-primary rounded-full shadow-lg active:scale-95 transition-all mb-1 mr-1"
                >
                  <Send className="w-5 h-5 fill-current" />
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-on-surface-variant font-bold text-xl">
            Select a message
          </div>
        )}
      </section>
    </div>
  );
};

const TopNav = ({ isDark, toggleTheme, onTabChange }: { isDark: boolean, toggleTheme: () => void, onTabChange: (tab: string) => void }) => {
  const { user, logout } = useAuth();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  return (
    <div className="sticky top-0 right-0 z-[100] flex items-center justify-end gap-4 p-4 bg-surface/80 backdrop-blur-md border-b border-outline-variant/10">
      {/* Theme Toggle Switch */}
      <button
        onClick={toggleTheme}
        className="w-14 h-8 bg-surface-container-high rounded-full relative p-1 transition-colors duration-300 focus:outline-none border border-outline-variant/20"
      >
        <motion.div
          animate={{ x: isDark ? 24 : 0 }}
          className="w-6 h-6 bg-primary rounded-full flex items-center justify-center shadow-lg"
        >
          {isDark ? <Moon className="w-4 h-4 text-on-primary" /> : <Sun className="w-4 h-4 text-on-primary" />}
        </motion.div>
      </button>

      {/* Profile Circle & Dropdown */}
      <div className="relative">
        <button
          onClick={() => setIsDropdownOpen(!isDropdownOpen)}
          className="flex items-center gap-2 bg-surface-container-low p-1.5 pr-3 rounded-full border border-outline-variant/20 hover:bg-surface-container transition-all"
        >
          <img
            src={user?.avatar_url || ''}
            alt="Profile"
            className="w-8 h-8 rounded-full object-cover border border-primary/20"
          />
          <ChevronDown className={`w-4 h-4 text-on-surface-variant transition-transform duration-200 ${isDropdownOpen ? 'rotate-180' : ''}`} />
        </button>

        <AnimatePresence>
          {isDropdownOpen && (
            <>
              <div className="fixed inset-0 z-[-1]" onClick={() => setIsDropdownOpen(false)} />
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                className="absolute right-0 mt-2 w-56 bg-surface-container-high rounded-2xl shadow-2xl border border-outline-variant/20 overflow-hidden py-2"
              >
                <div className="px-4 py-3 border-b border-outline-variant/10 mb-1">
                  <p className="text-sm font-bold text-on-surface truncate">{user?.name}</p>
                  <p className="text-xs text-on-surface-variant truncate">@{user?.handle}</p>
                </div>
                <button
                  onClick={() => {
                    logout();
                    setIsDropdownOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 text-sm font-semibold text-red-500 hover:bg-red-500/10 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

// --- Main App Layout ---

export const MainApp: React.FC = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [selectedHandle, setSelectedHandle] = useState<string | undefined>(undefined);
  const [selectedConversationId, setSelectedConversationId] = useState<number | undefined>(undefined);
  const { user, isDark, toggleTheme } = useAuth();

  const navigateToProfile = (handle: string) => {
    setSelectedHandle(handle);
    setActiveTab('profile');
  };

  const navigateToMessages = (userId?: number) => {
    setSelectedConversationId(userId);
    setActiveTab('messages');
  };

  const handleTabChange = (tab: string) => {
    if (tab === 'profile') setSelectedHandle(undefined);
    if (tab !== 'messages') setSelectedConversationId(undefined);
    setActiveTab(tab);
  };

  useEffect(() => {
    if (user) {
      // Fetch recent unread notifications and show toasts
      fetch(`/api/notifications/${user.id}`).then(res => res.json()).then(data => {
        const unread = data.filter((n: any) => !n.is_read).slice(0, 3);
        unread.forEach((n: any, i: number) => {
          setTimeout(() => {
            toast(
              <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('notifications')}>
                <img src={n.actor_avatar} className="w-8 h-8 rounded-full object-cover" />
                <div>
                  <p className="text-sm font-bold">@{n.actor_handle}</p>
                  <p className="text-xs opacity-80">
                    {n.type === 'like' && 'liked your post'}
                    {n.type === 'comment' && 'commented on your post'}
                    {n.type === 'follow' && 'started following you'}
                    {n.type === 'follow_request' && 'requested to follow you'}
                    {n.type === 'message' && 'sent you a message'}
                    {n.type === 'post' && 'posted a new update'}
                  </p>
                </div>
              </div>
            );
          }, i * 1500);
        });
      });
    }
  }, [user?.id]);

  return (
    <div className="flex min-h-screen max-w-7xl mx-auto relative bg-surface">
      <Sidebar activeTab={activeTab} onTabChange={handleTabChange} />
      <main className="flex-1 flex flex-col min-w-0">
        <TopNav isDark={isDark} toggleTheme={toggleTheme} onTabChange={handleTabChange} />
        {activeTab === 'home' && <FeedPage onProfileClick={navigateToProfile} />}
        {activeTab === 'search' && <SearchPage onProfileClick={navigateToProfile} />}
        {activeTab === 'messages' && <MessagesPage initialUserId={selectedConversationId} />}
        {activeTab === 'save' && <SavedPostsPage onProfileClick={navigateToProfile} />}
        {activeTab === 'profile' && <ProfilePage handle={selectedHandle} onProfileClick={navigateToProfile} onMessageClick={navigateToMessages} />}
        {activeTab === 'notifications' && <NotificationsPage />}
      </main>
      <RightSidebar onProfileClick={navigateToProfile} />
      
      {/* Mobile Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-surface/90 backdrop-blur-xl flex justify-around items-center py-3 z-50 border-t border-outline-variant/10">
        <button onClick={() => handleTabChange('home')} className={`p-2 ${activeTab === 'home' ? 'text-primary' : 'text-gray-400'}`}><Home className="w-6 h-6" /></button>
        <button onClick={() => handleTabChange('search')} className={`p-2 ${activeTab === 'search' ? 'text-primary' : 'text-gray-400'}`}><Search className="w-6 h-6" /></button>
        <button onClick={() => handleTabChange('messages')} className={`p-2 ${activeTab === 'messages' ? 'text-primary' : 'text-gray-400'}`}><Mail className="w-6 h-6" /></button>
        <button onClick={() => handleTabChange('notifications')} className={`p-2 ${activeTab === 'notifications' ? 'text-primary' : 'text-gray-400'}`}><Bell className="w-6 h-6" /></button>
        <button onClick={() => handleTabChange('profile')} className={`p-2 ${activeTab === 'profile' ? 'text-primary' : 'text-gray-400'}`}><User className="w-6 h-6" /></button>
      </nav>
    </div>
  );
};
