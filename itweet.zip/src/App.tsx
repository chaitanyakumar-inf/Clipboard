import React from 'react';
import { AuthProvider, useAuth } from './AuthContext';
import { AuthPage } from './AuthPage';
import { MainApp } from './MainApp';
import { Toaster } from 'sonner';

const AppContent: React.FC = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface text-primary">
        <div className="animate-pulse text-2xl font-black tracking-tighter">iTweet</div>
      </div>
    );
  }

  return user ? <MainApp /> : <AuthPage />;
};

export default function App() {
  return (
    <AuthProvider>
      <Toaster position="top-center" richColors theme="dark" />
      <AppContent />
    </AuthProvider>
  );
}
