import React, { useState } from 'react';
import { useAuth } from './AuthContext';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';
import { Zap, History, AtSign, CheckCircle, Info, Smartphone, MessageSquare, UserPlus, Sun, Moon, ChevronDown } from 'lucide-react';

export const AuthPage: React.FC = () => {
  const [step, setStep] = useState<'phone' | 'otp' | 'handle'>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [handle, setHandle] = useState('');
  const [tempUserId, setTempUserId] = useState<number | null>(null);
  const { login, isDark, toggleTheme } = useAuth();

  const handleRequestOtp = async () => {
    if (!phone) return toast.error("Please enter a phone number");
    const res = await fetch('/api/auth/request-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone }),
    });
    const data = await res.json();
    if (data.success) {
      toast.success(`OTP sent: ${data.otp}`, { duration: 10000 });
      setStep('otp');
    }
  };

  const handleVerifyOtp = async () => {
    const res = await fetch('/api/auth/verify-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, otp }),
    });
    const data = await res.json();
    if (data.success) {
      if (data.newUser) {
        setTempUserId(data.user.id);
        setStep('handle');
      } else {
        login(data.user);
      }
    } else {
      toast.error(data.message || "Invalid OTP");
    }
  };

  const handleRegister = async () => {
    if (!handle) return toast.error("Please choose a handle");
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: tempUserId, handle }),
    });
    const data = await res.json();
    if (data.success) {
      login(data.user);
    } else {
      toast.error(data.message || "Registration failed");
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-surface text-on-surface relative">
      <div className="absolute top-6 right-6 z-50">
        <button
          onClick={toggleTheme}
          className="w-12 h-12 bg-surface-container-high rounded-full flex items-center justify-center shadow-lg border border-outline-variant/20 hover:scale-110 transition-transform"
        >
          {isDark ? <Sun className="w-6 h-6 text-primary" /> : <Moon className="w-6 h-6 text-primary" />}
        </button>
      </div>
      <main className="w-full max-w-[440px] flex flex-col gap-12">
        <header className="flex flex-col items-center text-center gap-4">
          <div className="w-16 h-16 rounded-xl electric-gradient flex items-center justify-center shadow-[0_0_40px_rgba(153,203,255,0.2)]">
            <Zap className="text-on-primary w-10 h-10 fill-current" />
          </div>
          <div className="space-y-1">
            <h1 className="text-4xl font-black tracking-tighter text-on-surface">iTweet</h1>
            <p className="text-on-surface-variant font-medium tracking-wide">Enter the high-fidelity feed.</p>
          </div>
        </header>

        <section className="space-y-8">
          <AnimatePresence mode="wait">
            {step === 'phone' && (
              <motion.div
                key="phone"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <label className="text-sm font-bold uppercase tracking-widest text-primary px-1">Identity</label>
                  <div className="flex gap-3 h-14">
                    <div className="relative group/country">
                      <select 
                        className="w-32 h-full bg-surface-container-lowest rounded-xl border border-outline-variant/15 px-3 text-on-surface font-semibold outline-none focus:ring-1 focus:ring-primary appearance-none cursor-pointer"
                        onChange={(e) => {/* In a real app, we'd store the prefix */}}
                      >
                        <option value="+1">🇺🇸 +1</option>
                        <option value="+44">🇬🇧 +44</option>
                        <option value="+91">🇮🇳 +91</option>
                        <option value="+61">🇦🇺 +61</option>
                        <option value="+81">🇯🇵 +81</option>
                        <option value="+49">🇩🇪 +49</option>
                        <option value="+33">🇫🇷 +33</option>
                        <option value="+7">🇷🇺 +7</option>
                        <option value="+86">🇨🇳 +86</option>
                        <option value="+55">🇧🇷 +55</option>
                        <option value="+234">🇳🇬 +234</option>
                        <option value="+27">🇿🇦 +27</option>
                        <option value="+971">🇦🇪 +971</option>
                        <option value="+65">🇸🇬 +65</option>
                      </select>
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-on-surface-variant">
                        <ChevronDown className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="flex-1 relative group">
                      <input
                        className="w-full h-full bg-surface-container-lowest rounded-xl border border-outline-variant/15 px-4 text-on-surface placeholder:text-on-surface-variant/50 focus:ring-1 focus:ring-primary focus:border-primary transition-all duration-200 outline-none"
                        placeholder="Phone number"
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleRequestOtp()}
                      />
                    </div>
                  </div>
                </div>
                <button
                  onClick={handleRequestOtp}
                  className="w-full h-14 rounded-xl electric-gradient text-on-primary font-bold text-lg hover:opacity-90 active:scale-[0.98] transition-all duration-200"
                >
                  Get OTP
                </button>
                <div className="flex items-center gap-4 py-2">
                  <div className="h-[1px] flex-1 bg-outline-variant/15"></div>
                  <span className="text-xs font-bold text-outline uppercase tracking-widest">Trust & Transparency</span>
                  <div className="h-[1px] flex-1 bg-outline-variant/15"></div>
                </div>
                <div className="bg-surface-container-low p-5 rounded-xl flex gap-4 items-start border border-outline-variant/10">
                  <History className="text-tertiary w-6 h-6" />
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-tertiary">Verified Handle History</h4>
                    <p className="text-xs text-on-surface-variant leading-relaxed">We track handle history to prevent identity spoofing. Join a community built on authentic digital footprints.</p>
                  </div>
                </div>
              </motion.div>
            )}

            {step === 'otp' && (
              <motion.div
                key="otp"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <div className="flex justify-between items-end px-1">
                    <label className="text-sm font-bold uppercase tracking-widest text-primary">Verification</label>
                    <button onClick={handleRequestOtp} className="text-xs font-bold text-on-surface-variant hover:text-primary transition-colors">Resend</button>
                  </div>
                  <div className="grid grid-cols-4 gap-4 h-16">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <input
                        key={i}
                        maxLength={1}
                        autoFocus={i === 0}
                        className="bg-surface-container-lowest rounded-xl border border-primary flex items-center justify-center text-2xl font-bold text-primary text-center outline-none focus:ring-2 focus:ring-primary/20"
                        value={otp[i] || ''}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && otp.length === 4) handleVerifyOtp();
                          if (e.key === 'Backspace' && !otp[i] && (e.target as HTMLInputElement).previousElementSibling) {
                            ((e.target as HTMLInputElement).previousElementSibling as HTMLInputElement).focus();
                          }
                        }}
                        onChange={(e) => {
                          const newOtp = otp.split('');
                          newOtp[i] = e.target.value;
                          setOtp(newOtp.join(''));
                          if (e.target.value && (e.target as HTMLInputElement).nextElementSibling) {
                            ((e.target as HTMLInputElement).nextElementSibling as HTMLInputElement).focus();
                          }
                        }}
                      />
                    ))}
                  </div>
                </div>
                <button
                  onClick={handleVerifyOtp}
                  className="w-full h-14 rounded-xl electric-gradient text-on-primary font-bold text-lg hover:opacity-90 active:scale-[0.98] transition-all duration-200"
                >
                  Verify & Continue
                </button>
              </motion.div>
            )}

            {step === 'handle' && (
              <motion.div
                key="handle"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-surface-container p-8 rounded-2xl border border-outline-variant/10 shadow-2xl relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  <AtSign className="w-24 h-24" />
                </div>
                <div className="relative z-10 space-y-6">
                  <div className="space-y-2">
                    <h2 className="text-2xl font-bold text-on-surface">Claim your pulse</h2>
                    <p className="text-sm text-on-surface-variant">Choose a unique @handle. This will be your permanent identity anchor on iTweet.</p>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                      <span className="text-primary font-bold text-lg">@</span>
                    </div>
                    <input
                      className="w-full h-14 bg-surface-container-lowest rounded-xl border border-primary/40 pl-10 pr-4 text-lg font-semibold text-on-surface focus:ring-2 focus:ring-primary/20 transition-all outline-none"
                      placeholder="username"
                      type="text"
                      value={handle}
                      onChange={(e) => setHandle(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleRegister()}
                    />
                    {handle.length > 2 && (
                      <div className="absolute inset-y-0 right-4 flex items-center">
                        <CheckCircle className="text-primary w-6 h-6 fill-current" />
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-on-surface-variant font-bold uppercase tracking-tighter">
                    <Info className="w-3 h-3" />
                    Handle history will be visible on your public profile
                  </div>
                  <button
                    onClick={handleRegister}
                    className="w-full h-14 rounded-xl bg-on-surface text-surface font-bold text-lg hover:bg-white active:scale-[0.98] transition-all duration-200"
                  >
                    Finalize Profile
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>

        <footer className="text-center px-4">
          <p className="text-[11px] leading-relaxed text-on-surface-variant/60 font-medium">
            By continuing, you agree to our <a className="text-primary hover:underline" href="#">Terms of Service</a> and <a className="text-primary hover:underline" href="#">Privacy Policy</a>. Standard SMS rates may apply for OTP verification. iTweet employs advanced handle tracking for platform integrity.
          </p>
        </footer>
      </main>

      <div className="fixed top-0 left-0 w-full h-full -z-10 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-primary/5 blur-[120px]"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-tertiary/5 blur-[120px]"></div>
      </div>
    </div>
  );
};
