import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, loadEnv} from 'vite';

export default defineConfig(({mode}) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [react(), tailwindcss()],
    theme: {
      extend: {
        colors: {
          "on-surface": "#e2e2e2",
          "surface": "#131313",
          "surface-container": "#1f1f1f",
          "surface-container-high": "#2a2a2a",
          "surface-container-low": "#1b1b1b",
          "surface-container-lowest": "#0e0e0e",
          "surface-container-highest": "#353535",
          "surface-bright": "#393939",
          "surface-dim": "#131313",
          "primary": "#99cbff",
          "primary-container": "#1097eb",
          "on-primary": "#003354",
          "on-primary-container": "#002c4a",
          "secondary": "#c2c7cc",
          "secondary-container": "#42474c",
          "on-secondary": "#2c3135",
          "tertiary": "#cabeff",
          "tertiary-container": "#947dff",
          "on-tertiary": "#31009a",
          "outline": "#8b90a0",
          "outline-variant": "#414754",
          "on-surface-variant": "#c1c6d7",
          "error": "#ffb4ab",
          "error-container": "#93000a",
        },
        fontFamily: {
          sans: ["Inter", "sans-serif"],
        },
      },
    },
    define: {
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY),
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
    },
  };
});
