import tkinter as tk
from tkinter import ttk
import qrcode
from PIL import Image, ImageTk


class QRGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Real-Time QR Code Generator")
        self.root.geometry("700x600")

        # Title
        title_label = ttk.Label(
            root,
            text="Real-Time QR Code Generator",
            font=("Arial", 16, "bold")
        )
        title_label.pack(pady=10)

        # Text Input
        self.text_input = tk.Text(
            root,
            wrap=tk.WORD,
            height=10,
            font=("Arial", 11)
        )
        self.text_input.pack(fill=tk.BOTH, expand=False, padx=10, pady=10)

        # Bind key release for realtime updates
        self.text_input.bind("<KeyRelease>", self.generate_qr)

        # QR Display Label
        self.qr_label = ttk.Label(root)
        self.qr_label.pack(pady=20)

        # Initial QR
        self.generate_qr()

    def generate_qr(self, event=None):
        text = self.text_input.get("1.0", tk.END).strip()

        if not text:
            text = " "

        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=8,
            border=4
        )

        qr.add_data(text)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        img = img.resize((300, 300))

        photo = ImageTk.PhotoImage(img)

        self.qr_label.config(image=photo)
        self.qr_label.image = photo


if __name__ == "__main__":
    root = tk.Tk()
    app = QRGeneratorApp(root)
    root.mainloop()