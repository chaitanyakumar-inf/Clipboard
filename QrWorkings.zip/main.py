import customtkinter as ctk
import qrcode
from PIL import Image, ImageOps

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("dark-blue")


class QRGeneratorApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("QR Studio - Fail-Safe Scanner")
        self.geometry("900x800")
        self.minsize(500, 500)
        self.configure(fg_color="#0A0A0C")

        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0)
        self.grid_columnconfigure(0, weight=1)

        # ---------------- 1. Hero QR Display Stage ----------------
        self.hero_stage = ctk.CTkFrame(
            self,
            corner_radius=24,
            fg_color="#121215",
            border_width=1,
            border_color="#222226"
        )
        self.hero_stage.grid(row=0, column=0, padx=24, pady=(24, 12), sticky="nsew")

        self.qr_label = ctk.CTkLabel(self.hero_stage, text="")
        self.qr_label.pack(expand=True, fill="both", padx=32, pady=32)

        # ---------------- 2. Input Control Bar ----------------
        self.control_bar = ctk.CTkFrame(
            self,
            corner_radius=18,
            fg_color="#121215",
            border_width=1,
            border_color="#222226"
        )
        self.control_bar.grid(row=1, column=0, padx=24, pady=(12, 24), sticky="ew")

        self.text_input = ctk.CTkEntry(
            self.control_bar,
            placeholder_text="Paste URL or text here...",
            height=48,
            corner_radius=12,
            fg_color="#0A0A0C",
            text_color="#FAFAFA",
            placeholder_text_color="#52525B",
            border_width=1,
            border_color="#27272A",
            font=("Segoe UI", 14)
        )
        self.text_input.pack(fill="x", padx=16, pady=16)

        self.text_input.bind("<KeyRelease>", self.generate_qr)
        self.hero_stage.bind("<Configure>", self.on_resize)

        self.last_qr_img = None
        self.current_qr_size = 300

        self.generate_qr()

    def generate_qr(self, event=None):
        payload = self.text_input.get().strip()
        if not payload:
            payload = " "

        # Standard black-on-white QR with a generous quiet zone border
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=4  # Standard 4-module quiet zone required by QR spec
        )

        qr.add_data(payload)
        qr.make(fit=True)

        # Generating standard black-on-white image (universal compatibility)
        img = qr.make_image(fill_color="black", back_color="white").convert("RGB")

        # Add a sleek dark padding frame around the white card so it blends into our dark theme
        self.last_qr_img = ImageOps.expand(img, border=12, fill="#121215")

        self.update_qr_display()

    def on_resize(self, event):
        available_width = event.width - 64
        available_height = event.height - 64
        new_size = max(150, min(available_width, available_height))

        if abs(self.current_qr_size - new_size) > 10:
            self.current_qr_size = new_size
            self.update_qr_display()

    def update_qr_display(self):
        if self.last_qr_img is None:
            return

        size = int(self.current_qr_size)
        resized_pil = self.last_qr_img.resize((size, size), Image.Resampling.LANCZOS)

        ctk_img = ctk.CTkImage(
            light_image=resized_pil,
            dark_image=resized_pil,
            size=(size, size)
        )

        self.qr_label.configure(image=ctk_img)
        self.qr_label.image = ctk_img


if __name__ == "__main__":
    app = QRGeneratorApp()
    app.mainloop()